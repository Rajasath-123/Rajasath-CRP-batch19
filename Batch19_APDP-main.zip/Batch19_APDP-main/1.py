print("hello")
print("Hello")