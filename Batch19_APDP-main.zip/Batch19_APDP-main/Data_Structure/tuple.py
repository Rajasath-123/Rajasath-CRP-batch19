tuple = (1,3,1,2,3)

tuple= tuple + (1,4,5)
print(tuple)


